#define EXE_NAME "D:/Error_Non_36"
#define ROOT_PATH "D:/Error_Non_36/"
#define RUN_PATH "D:/Error_Non_36/Debug/Error_Non_36.exe"